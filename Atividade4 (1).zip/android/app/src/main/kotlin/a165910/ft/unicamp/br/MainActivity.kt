package a165910.ft.unicamp.br

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

class UserModel {
  final String uid;

  UserModel(this.uid);
}

import '../model/notes.dart';

class MonitorState {
  NoteCollection noteCollection;
  MonitorState({required this.noteCollection});
}
